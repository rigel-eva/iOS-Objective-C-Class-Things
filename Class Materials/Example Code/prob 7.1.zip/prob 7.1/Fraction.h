//
//  Fraction.h
//  prob 7.1
//
//  Created by jitin on 9/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Fraction.h"


// The Fraction class
@interface Fraction : NSObject
{
	int numerator;
	int denominator;
}
-(void) print;
-(void) setNumerator: (int) n;
-(void) setDenominator: (int) d;
-(int) numerator;
-(int) denominator;
-(double) convertToNum;
@end