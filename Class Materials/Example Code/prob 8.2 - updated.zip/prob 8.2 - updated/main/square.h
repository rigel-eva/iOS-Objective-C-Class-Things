//
//  square.h
//  main
//
//  Created by jitin on 9/11/13.
//
//

#import <Cocoa/Cocoa.h>
#import "rectangle.h"

@interface square : Rectangle

-(void) setSQSide:(int)side;

@end
