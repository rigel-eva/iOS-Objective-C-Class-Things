#import "rectangle.h"
#import "square.h"

int main (int argc, const char * argv[]) {
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];

//	Rectangle *myRect = [[Rectangle alloc] init];
//	[myRect setWidth: 5 andHeight: 8];
//	NSLog (@"Rectangle: w = %i, h = %i",
//		   myRect.width, myRect.height);
//	NSLog (@"Area = %i, Perimeter = %i",
//		   [myRect area], [myRect perimeter]);
//	
//	[myRect release];
    
    square *mySquare = [[square alloc] init];
    [mySquare setSQSide:4];
    
    NSLog(@"Square: w = %i, h = %i", mySquare.width, mySquare.height);
    NSLog(@"Area = %i, perimeter = %i", [mySquare area], [mySquare perimeter]);
    
    
    // Class question - width property comes from where and what type of property it is?
    
    mySquare.width = 5;
    
    //  class Questions - this is not allowed - why?
    // [mySquare height] = 6;
    
    [mySquare setHeight:6];
    
    NSLog(@"with Dot notation - Square: w = %i, h = %i", mySquare.width, mySquare.height);
    
    // We can read property values through getter method as well
    NSLog(@"By invoking getter methods - Square: w = %i, h = %i", [mySquare width], [mySquare height]);

    NSLog(@"Area = %i, perimeter = %i", [mySquare area], [mySquare perimeter]);
    
    
    
    [mySquare release];
	[pool drain];
	return 0;
}