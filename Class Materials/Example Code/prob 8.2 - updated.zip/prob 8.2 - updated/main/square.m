//
//  square.m
//  main
//
//  Created by jitin on 9/11/13.
//
//

#import "square.h"

@implementation square

- (void) setSQSide:(int)side {

        width = side;
        height = side;
   
    
}

@end
