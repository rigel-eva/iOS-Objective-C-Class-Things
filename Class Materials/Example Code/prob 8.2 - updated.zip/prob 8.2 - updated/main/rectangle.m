//
//  rectangle.m
//  main
//
//  Created by jitin on 9/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "rectangle.h"

@implementation Rectangle
@synthesize width, height;

-(void) setWidth: (int) w andHeight: (int) h
{
	width = w;
	height = h;
}
-(int) area
{
	return width * height;
}
-(int) perimeter
{
	return (width + height) * 2;
}
@end