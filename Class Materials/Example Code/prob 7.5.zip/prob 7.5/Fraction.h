//
//  Fraction.h
//  prob 7.1
//
//  Created by jitin on 9/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


// The Fraction class
@interface Fraction : NSObject
{
	int numerator;
	int denominator;
}

@property int numerator, denominator; // declare properties for synthesizer

-(void) print;
// -(void) setNumerator: (int) n;
// -(void) setDenominator: (int) d;
// -(int) numerator;
// -(int) denominator;
-(void)   setTo: (int) n over: (int) d;  // added new method
-(double) convertToNum;
-(void) add:(Fraction *)f;
-(void) reduce;
@end