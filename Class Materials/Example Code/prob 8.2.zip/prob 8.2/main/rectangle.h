//
//  rectangle.h
//  main
//
//  Created by jitin on 9/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

@interface Rectangle: NSObject
{
	int width;
	int height;
}
@property int width, height;
-(int) area;
-(int) perimeter;
-(void) setWidth:(int) n andHeight: (int) w;
@end
