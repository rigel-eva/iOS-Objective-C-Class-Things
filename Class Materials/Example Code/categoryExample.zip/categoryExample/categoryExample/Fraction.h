//
//  Fraction.h
//  categoryExample
//
//  Created by jitin on 9/9/14.
//  Copyright (c) 2014 jitin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Fraction : NSObject
{
	int	numerator;
	int 	denominator;
}

-(void)	setNumerator: (int) n;
-(void)	setDenominator:	(int) d;
-(void)	setTo: (int) n over: (int) d;

-(int)  numerator;
-(int)  denominator;

-(void)   reduce;
-(double) convertToNum;
-(void)	  print;

@end
