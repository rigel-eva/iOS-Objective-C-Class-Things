//
//  main.m
//  categoryExample
//
//  Created by jitin on 9/9/14.
//  Copyright (c) 2014 jitin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MathOpsCategory.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // insert code here...
        NSLog(@"Hello, Category World!!!!\n\n");
        
        Fraction  *a = [[Fraction alloc] init];
        Fraction  *b = [[Fraction alloc] init];
        Fraction  *result;
        
        [a setTo: 1 over: 3];
        [b setTo: 2 over: 5];
        
        [a print]; printf (" + "); [b print]; printf (" = ");
        result = [a add: b];    // using "add" category defined in MathOpsCategory.h
        [result print];
        printf ("\n");
        
        [a print]; printf (" - "); [b print]; printf (" = ");
        result = [a sub: b];    // using "sub" category defined in MathOpsCategory.h
        [result print];
        printf ("\n");
        
        [a print]; printf (" * "); [b print]; printf (" = ");
        result = [a mul: b];    // using "mul" category defined in MathOpsCategory.h
        [result print];
        printf ("\n");
        
        [a print]; printf (" / "); [b print]; printf (" = ");
        result = [a div: b];    // using "div" category defined in MathOpsCategory.h
        [result print];
        printf ("\n");

        
    }
    return 0;
}

