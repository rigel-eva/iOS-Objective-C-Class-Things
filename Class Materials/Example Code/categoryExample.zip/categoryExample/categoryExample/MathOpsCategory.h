//
//  MathOpsCategory.h
//  categoryExample
//
//  Created by jitin on 9/9/14.
//  Copyright (c) 2014 jitin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Fraction.h"

@interface Fraction (MathOps)
-(Fraction *) add: (Fraction *) f;
-(Fraction *) mul: (Fraction *) f;
-(Fraction *) sub: (Fraction *) f;
-(Fraction *) div: (Fraction *) f;
@end
