#import <Foundation/Foundation.h>
// ClassA declaration and definition
@interface ClassA: NSObject
{
	int x;
    int y;
}
-(void) initVar;
@end
@implementation ClassA
-(void) initVar
{
    y = 50;
	x = 100;
}
@end
// ClassB declaration and definition
@interface ClassB: ClassA
//-(void) initVar; // removed from defination
-(void) printVar;
@end
@implementation ClassB
-(void) initVar // added method
{
	x = 200;
}
-(void) printVar
{
	NSLog (@"x = %i", x);
    NSLog (@"y = %i", y);
}
@end
int main (int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	ClassB *b = [[ClassB alloc] init];
    [b printVar];
    NSLog(@" Now overriding in B");
	[b initVar]; // uses overriding method in B
	[b printVar]; // reveal value of x;
	[b release];
	[pool drain];
	return 0;
}
