//
//  XYPoint.m
//  main
//
//  Created by jitin on 9/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "XYPoint.h"


@implementation XYPoint
@synthesize x, y;
-(void) setX: (int) xVal andY: (int) yVal
{
	x = xVal;
	y = yVal;
}
@end