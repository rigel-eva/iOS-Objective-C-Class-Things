//
//  XYPoint.h
//  main
//
//  Created by jitin on 9/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface XYPoint: NSObject
{
	int x;
	int y;
}
@property int x, y;
-(void) setX: (int) xVal andY: (int) yVal;
@end
